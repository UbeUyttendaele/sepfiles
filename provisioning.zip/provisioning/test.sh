#! /bin/bash
    dnf install postgresql-server nginx -y

    postgresql-setup --initdb &> /dev/null
    systemctl enable --now postgresql
    cp database.sh /tmp/
    sudo -u postgres /tmp/database.sh

    yum install epel-release yum-utils -y
    yum install http://rpms.remirepo.net/enterprise/remi-release-7.rpm -y
    yum-config-manager --enable remi-php72 -y
    yum install -y php-cli php-fpm php-pdo php-json php-opcache php-mbstring php-xml php-gd php-curl php-pgsql git

    cp ./www.conf /etc/php-fpm.d/www.conf

    chown -R root:nginx /var/lib/php

    sudo chown -R root:nginx /var/lib/php
    
    sudo systemctl enable php-fpm
    sudo systemctl start php-fpm

    
    

    curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer
    composer --version

    /usr/local/bin/composer create-project drupal-composer/drupal-project:8.x-dev /var/www/my_drupal --stability dev --no-interaction

    cp ./example.com /etc/nginx/conf.d/example.com

    chown -R nginx: /var/www/my_drupal

    sudo systemctl restart nginx

    