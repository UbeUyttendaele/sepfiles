#! /bin/bash

RED='\033[0;31m'
NC='\033[0m' # No Color
#example: echo -e "I ${RED}love${NC} Stack Overflow"

echo -e "${RED}Installing nginx, php & postgresql${NC}"
    dnf install -y vim &> /dev/null
    dnf install -y epel-release &> /dev/null
    dnf install -y dnf-utils http://rpms.remirepo.net/enterprise/remi-release-8.rpm &> /dev/null
    dnf module reset php -y &> /dev/null
    dnf module enable php:remi-8.1 -y &> /dev/null
    dnf install nginx postgresql-server php php-fpm php-cli php-mbstring php-gd php-xml php-curl php-pdo php-json php-opcache php-pgsql -y &> /dev/null
    systemctl enable --now nginx &> /dev/null
    systemctl enable --now php-fpm &> /dev/null
    wget https://getcomposer.org/installer -O composer-installer.php &> /dev/null
    php composer-installer.php global --filename=composer --install-dir=/bin/ &> /dev/null
    systemctl enable --now nginx &> /dev/null
    systemctl enable --now php-fpm &> /dev/null
    rm composer-installer.php &> /dev/null

echo -e "${RED}Configuring postgresql${NC}"
    postgresql-setup --initdb &> /dev/null
    systemctl enable --now postgresql
    cp database.sh /tmp/
    sudo -u postgres /tmp/database.sh

echo -e "${RED}Restarting services${NC}"
    systemctl restart php-fpm
    systemctl restart nginx
    systemctl restart postgresql
echo -e "${RED}Done${NC}"