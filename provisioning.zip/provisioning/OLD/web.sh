#! /bin/bash

# echo "Cheching interface file type and configuring it"
# echo "Determening interface name"
#     ifconfig -a > interfacenaam
#     interface=$(cut -d : -f 1 interfacenaam | head -n 1)
#     rm interfacenaam
# echo "Interface name found: $interface"
# echo "Configuring interface: $interface"
#     FILE=/etc/sysconfig/network-scripts/ifcfg-$interface
#     echo "DEVICE=$interface" > "$FILE"
#     echo "BOOTPROTO=none" >> "$FILE"
#     echo "ONBOOT=yes" >> "$FILE"
#     echo "IPADDR=192.168.1.34" >> "$FILE"
#     echo "PREFIX=29" >> "$FILE"
#     echo "GATEWAY=192.168.1.33" >> "$FILE"
#     ifdown $interface
#     ifup $interface
# echo "interface file configured"
    dnf install vim
echo "Installing nginx, php & postgresql"
    dnf install -y epel-release  
    dnf install -y dnf-utils http://rpms.remirepo.net/enterprise/remi-release-8.rpm 
    dnf module reset php -y 
    dnf module enable php:remi-8.1 -y 
    dnf install nginx postgresql-server php php-fpm php-cli php-mbstring php-gd php-xml php-curl php-pdo php-json php-opcache php-pgsql -y
    systemctl enable --now nginx &> /dev/null
    systemctl enable --now php-fpm &> /dev/null
    wget https://getcomposer.org/installer -O composer-installer.php
    php composer-installer.php global --filename=composer --install-dir=/
    systemctl enable --now nginx &> /dev/null
    systemctl enable --now php-fpm &> /dev/null
    rm composer-installer.php
echo "Installed nginx, php & postgresql"
echo "Configuring postgresql"
    postgresql-setup --initdb &> /dev/null
    systemctl enable --now postgresql
    cp database.sh /tmp/
    sudo -u postgres /tmp/database.sh

echo "Installing Drupal"
    /composer create-project --no-interaction drupal/recommended-project /var/www/html/drupal
    cd /var/www/html/drupal
    /composer require --no-interaction 'drupal/admin_toolbar:^3.1'
echo "Installed Drupal"
echo "Configuring Drupal"
    mkdir /var/www/html/drupal/web/sites/default/files &> /dev/null
    cp /var/www/html/drupal/web/sites/default/default.settings.php /var/www/html/drupal/web/sites/default/settings.php &> /dev/null
    chown -R nginx:nginx /var/www/html/drupal/web
    rm /var/www/html/drupal/web/.htaccass
    #cp php-fmd.ddrupal.conf /etc/php-fpm.d/drupal.conf
    cp nginxdrupal.conf /etc/nginx/conf.d/drupal.conf

    chmod 773 /var/www/html/drupal/web/sites/default/files/
    chmod 776 /var/www/html/drupal/web/sites/default/settings.php
echo "Configured Drupal "



echo "Configuring nginx"
    sed -iz '/       root         \/usr\/share\/nginx\/html;/c\        root         \/var\/www\/html\/drupal\/web;' /etc/nginx/nginx.conf
echo "Configured nginx"
echo "Restarting services"
    systemctl restart php-fpm
    systemctl restart nginx
    systemctl restart postgresql
echo "Restarted services"


echo "Configuring SELinux"
    semanage fcontext -a -t httpd_sys_rw_content_t "/var/www/html/drupal(/.*)?" &> /dev/null
    semanage fcontext -a -t httpd_sys_rw_content_t '/var/www/html/drupal/web/sites/default/settings.php' &> /dev/null
    semanage fcontext -a -t httpd_sys_rw_content_t '/var/www/html/drupal/web/sites/default/files' &> /dev/null
    restorecon -Rv /var/www/html/drupal/web &> /dev/null
    restorecon -v /var/www/html/drupal/web/sites/default/settings.php &> /dev/null
    restorecon -Rv /var/www/html/drupal/web/sites/default/files &> /dev/null
echo "Configured SElinux"
echo "Configuring firewall"
    # systemctl enable --now firewalld &> /dev/null
    firewall-cmd --permanent --add-service=http &> /dev/null
    firewall-cmd --permanent --add-service=https &> /dev/null
    firewall-cmd --reload &> /dev/null
echo "Configured firewall"