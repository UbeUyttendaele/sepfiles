#! /bin/bash
echo "Installing nginx, php & postgresql"
    dnf install -y epel-release  
    dnf install -y dnf-utils http://rpms.remirepo.net/enterprise/remi-release-8.rpm 
    dnf update -y 
    dnf remove php php-fpm -y 
    dnf remove php* -y 
    dnf module reset php -y 
    dnf module enable php:remi-8.1 -y 
    dnf install nginx postgresql-server php php-fpm php-cli php-mbstring php-gd php-xml php-curl php-pdo php-json php-opcache php-pgsql -y
    systemctl enable --now nginx &> /dev/null
    systemctl enable --now php-fpm &> /dev/null
    wget https://getcomposer.org/installer -O composer-installer.php
    php composer-installer.php global --filename=composer --install-dir=/
    systemctl enable --now nginx &> /dev/null
    systemctl enable --now php-fpm &> /dev/null
    rm composer-installer.php
echo "Installed nginx, php & postgresql"